module ApplicantsHelper
	
end
